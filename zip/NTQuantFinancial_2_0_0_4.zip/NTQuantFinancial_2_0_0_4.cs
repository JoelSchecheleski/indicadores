#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial[] cacheGexCumulativeDeltaNTQuantFinancial;
		private GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial[] cacheGexDeltaVolumeNTQuantFinancial;
		private GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial[] cacheGexGamaBarsAutomaticNTQuantFinancial;
		private GexNTQuantFinancial.GexGamaBarsNTQauntFinancial[] cacheGexGamaBarsNTQauntFinancial;
		private GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial[] cacheGexGamaLevelsAutomaticNTQuantFinancial;
		private GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial[] cacheGexGamaLevelsNTQuantFinancial;
		private GexNTQuantFinancial.GexMultiPropFirmManager[] cacheGexMultiPropFirmManager;
		private GexNTQuantFinancial.GexNewCumulativeDelta[] cacheGexNewCumulativeDelta;
		private GexNTQuantFinancial.RSINTQuantFinancial[] cacheRSINTQuantFinancial;
		private GexNTQuantFinancial.SettlementPriceNTQuantFinancial[] cacheSettlementPriceNTQuantFinancial;
		private GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial[] cacheGexTextGraphicSymbolNTQuantFinancial;
		private GexNTQuantFinancial.VolumeProfileNtQuantFinancial[] cacheVolumeProfileNtQuantFinancial;
		private GexNTQuantFinancial.GexWeisWave[] cacheGexWeisWave;

		
		public GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial()
		{
			return GexCumulativeDeltaNTQuantFinancial(Input);
		}

		public GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial()
		{
			return GexDeltaVolumeNTQuantFinancial(Input);
		}

		public GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(float opacityBars, bool showSocials)
		{
			return GexGamaBarsAutomaticNTQuantFinancial(Input, opacityBars, showSocials);
		}

		public GexNTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return GexGamaBarsNTQauntFinancial(Input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return GexGamaLevelsAutomaticNTQuantFinancial(Input, font, customFontDisplayText, showSocials);
		}

		public GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return GexGamaLevelsNTQuantFinancial(Input, parameters, font, customFontDisplayText, showSocials);
		}

		public GexNTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return GexMultiPropFirmManager(Input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public GexNTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(int cumulationLength, bool highlight)
		{
			return GexNewCumulativeDelta(Input, cumulationLength, highlight);
		}

		public GexNTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(int period, int smooth)
		{
			return RSINTQuantFinancial(Input, period, smooth);
		}

		public GexNTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(bool isUsingRTHSession)
		{
			return SettlementPriceNTQuantFinancial(Input, isUsingRTHSession);
		}

		public GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(int wMSize, int wMOpacity, string customText)
		{
			return GexTextGraphicSymbolNTQuantFinancial(Input, wMSize, wMOpacity, customText);
		}

		public GexNTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(int resolution)
		{
			return VolumeProfileNtQuantFinancial(Input, resolution);
		}

		public GexNTQuantFinancial.GexWeisWave GexWeisWave(int period)
		{
			return GexWeisWave(Input, period);
		}


		
		public GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial(ISeries<double> input)
		{
			if (cacheGexCumulativeDeltaNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexCumulativeDeltaNTQuantFinancial.Length; idx++)
					if ( cacheGexCumulativeDeltaNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexCumulativeDeltaNTQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial>(new GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial(), input, ref cacheGexCumulativeDeltaNTQuantFinancial);
		}

		public GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial(ISeries<double> input)
		{
			if (cacheGexDeltaVolumeNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexDeltaVolumeNTQuantFinancial.Length; idx++)
					if ( cacheGexDeltaVolumeNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexDeltaVolumeNTQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial>(new GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial(), input, ref cacheGexDeltaVolumeNTQuantFinancial);
		}

		public GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(ISeries<double> input, float opacityBars, bool showSocials)
		{
			if (cacheGexGamaBarsAutomaticNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexGamaBarsAutomaticNTQuantFinancial.Length; idx++)
					if (cacheGexGamaBarsAutomaticNTQuantFinancial[idx].opacityBars == opacityBars && cacheGexGamaBarsAutomaticNTQuantFinancial[idx].showSocials == showSocials && cacheGexGamaBarsAutomaticNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexGamaBarsAutomaticNTQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial>(new GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial(){ opacityBars = opacityBars, showSocials = showSocials }, input, ref cacheGexGamaBarsAutomaticNTQuantFinancial);
		}

		public GexNTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(ISeries<double> input, float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			if (cacheGexGamaBarsNTQauntFinancial != null)
				for (int idx = 0; idx < cacheGexGamaBarsNTQauntFinancial.Length; idx++)
					if (cacheGexGamaBarsNTQauntFinancial[idx].opacityBars == opacityBars && cacheGexGamaBarsNTQauntFinancial[idx].scaleGex == scaleGex && cacheGexGamaBarsNTQauntFinancial[idx].minimumGex == minimumGex && cacheGexGamaBarsNTQauntFinancial[idx].GexJson == gexJson && cacheGexGamaBarsNTQauntFinancial[idx].showSocials == showSocials && cacheGexGamaBarsNTQauntFinancial[idx].EqualsInput(input))
						return cacheGexGamaBarsNTQauntFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.GexGamaBarsNTQauntFinancial>(new GexNTQuantFinancial.GexGamaBarsNTQauntFinancial(){ opacityBars = opacityBars, scaleGex = scaleGex, minimumGex = minimumGex, GexJson = gexJson, showSocials = showSocials }, input, ref cacheGexGamaBarsNTQauntFinancial);
		}

		public GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(ISeries<double> input, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			if (cacheGexGamaLevelsAutomaticNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexGamaLevelsAutomaticNTQuantFinancial.Length; idx++)
					if (cacheGexGamaLevelsAutomaticNTQuantFinancial[idx].Font == font && cacheGexGamaLevelsAutomaticNTQuantFinancial[idx].customFontDisplayText == customFontDisplayText && cacheGexGamaLevelsAutomaticNTQuantFinancial[idx].showSocials == showSocials && cacheGexGamaLevelsAutomaticNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexGamaLevelsAutomaticNTQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial>(new GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial(){ Font = font, customFontDisplayText = customFontDisplayText, showSocials = showSocials }, input, ref cacheGexGamaLevelsAutomaticNTQuantFinancial);
		}

		public GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(ISeries<double> input, string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			if (cacheGexGamaLevelsNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexGamaLevelsNTQuantFinancial.Length; idx++)
					if (cacheGexGamaLevelsNTQuantFinancial[idx].Parameters == parameters && cacheGexGamaLevelsNTQuantFinancial[idx].Font == font && cacheGexGamaLevelsNTQuantFinancial[idx].customFontDisplayText == customFontDisplayText && cacheGexGamaLevelsNTQuantFinancial[idx].showSocials == showSocials && cacheGexGamaLevelsNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexGamaLevelsNTQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial>(new GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial(){ Parameters = parameters, Font = font, customFontDisplayText = customFontDisplayText, showSocials = showSocials }, input, ref cacheGexGamaLevelsNTQuantFinancial);
		}

		public GexNTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(ISeries<double> input, double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			if (cacheGexMultiPropFirmManager != null)
				for (int idx = 0; idx < cacheGexMultiPropFirmManager.Length; idx++)
					if (cacheGexMultiPropFirmManager[idx].GainLimit == gainLimit && cacheGexMultiPropFirmManager[idx].StopLimit == stopLimit && cacheGexMultiPropFirmManager[idx].Font == font && cacheGexMultiPropFirmManager[idx].StopFillBrush == stopFillBrush && cacheGexMultiPropFirmManager[idx].TargetFillBrush == targetFillBrush && cacheGexMultiPropFirmManager[idx].OutlineBrush == outlineBrush && cacheGexMultiPropFirmManager[idx].TextBrush == textBrush && cacheGexMultiPropFirmManager[idx].MasterAccount_name == masterAccount_name && cacheGexMultiPropFirmManager[idx].Accountname_1 == accountname_1 && cacheGexMultiPropFirmManager[idx].Accountname_2 == accountname_2 && cacheGexMultiPropFirmManager[idx].Accountname_3 == accountname_3 && cacheGexMultiPropFirmManager[idx].Accountname_4 == accountname_4 && cacheGexMultiPropFirmManager[idx].Accountname_5 == accountname_5 && cacheGexMultiPropFirmManager[idx].EqualsInput(input))
						return cacheGexMultiPropFirmManager[idx];
			return CacheIndicator<GexNTQuantFinancial.GexMultiPropFirmManager>(new GexNTQuantFinancial.GexMultiPropFirmManager(){ GainLimit = gainLimit, StopLimit = stopLimit, Font = font, StopFillBrush = stopFillBrush, TargetFillBrush = targetFillBrush, OutlineBrush = outlineBrush, TextBrush = textBrush, MasterAccount_name = masterAccount_name, Accountname_1 = accountname_1, Accountname_2 = accountname_2, Accountname_3 = accountname_3, Accountname_4 = accountname_4, Accountname_5 = accountname_5 }, input, ref cacheGexMultiPropFirmManager);
		}

		public GexNTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(ISeries<double> input, int cumulationLength, bool highlight)
		{
			if (cacheGexNewCumulativeDelta != null)
				for (int idx = 0; idx < cacheGexNewCumulativeDelta.Length; idx++)
					if (cacheGexNewCumulativeDelta[idx].CumulationLength == cumulationLength && cacheGexNewCumulativeDelta[idx].Highlight == highlight && cacheGexNewCumulativeDelta[idx].EqualsInput(input))
						return cacheGexNewCumulativeDelta[idx];
			return CacheIndicator<GexNTQuantFinancial.GexNewCumulativeDelta>(new GexNTQuantFinancial.GexNewCumulativeDelta(){ CumulationLength = cumulationLength, Highlight = highlight }, input, ref cacheGexNewCumulativeDelta);
		}

		public GexNTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(ISeries<double> input, int period, int smooth)
		{
			if (cacheRSINTQuantFinancial != null)
				for (int idx = 0; idx < cacheRSINTQuantFinancial.Length; idx++)
					if (cacheRSINTQuantFinancial[idx].Period == period && cacheRSINTQuantFinancial[idx].Smooth == smooth && cacheRSINTQuantFinancial[idx].EqualsInput(input))
						return cacheRSINTQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.RSINTQuantFinancial>(new GexNTQuantFinancial.RSINTQuantFinancial(){ Period = period, Smooth = smooth }, input, ref cacheRSINTQuantFinancial);
		}

		public GexNTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(ISeries<double> input, bool isUsingRTHSession)
		{
			if (cacheSettlementPriceNTQuantFinancial != null)
				for (int idx = 0; idx < cacheSettlementPriceNTQuantFinancial.Length; idx++)
					if (cacheSettlementPriceNTQuantFinancial[idx].IsUsingRTHSession == isUsingRTHSession && cacheSettlementPriceNTQuantFinancial[idx].EqualsInput(input))
						return cacheSettlementPriceNTQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.SettlementPriceNTQuantFinancial>(new GexNTQuantFinancial.SettlementPriceNTQuantFinancial(){ IsUsingRTHSession = isUsingRTHSession }, input, ref cacheSettlementPriceNTQuantFinancial);
		}

		public GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(ISeries<double> input, int wMSize, int wMOpacity, string customText)
		{
			if (cacheGexTextGraphicSymbolNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexTextGraphicSymbolNTQuantFinancial.Length; idx++)
					if (cacheGexTextGraphicSymbolNTQuantFinancial[idx].WMSize == wMSize && cacheGexTextGraphicSymbolNTQuantFinancial[idx].WMOpacity == wMOpacity && cacheGexTextGraphicSymbolNTQuantFinancial[idx].CustomText == customText && cacheGexTextGraphicSymbolNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexTextGraphicSymbolNTQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial>(new GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial(){ WMSize = wMSize, WMOpacity = wMOpacity, CustomText = customText }, input, ref cacheGexTextGraphicSymbolNTQuantFinancial);
		}

		public GexNTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(ISeries<double> input, int resolution)
		{
			if (cacheVolumeProfileNtQuantFinancial != null)
				for (int idx = 0; idx < cacheVolumeProfileNtQuantFinancial.Length; idx++)
					if (cacheVolumeProfileNtQuantFinancial[idx].Resolution == resolution && cacheVolumeProfileNtQuantFinancial[idx].EqualsInput(input))
						return cacheVolumeProfileNtQuantFinancial[idx];
			return CacheIndicator<GexNTQuantFinancial.VolumeProfileNtQuantFinancial>(new GexNTQuantFinancial.VolumeProfileNtQuantFinancial(){ Resolution = resolution }, input, ref cacheVolumeProfileNtQuantFinancial);
		}

		public GexNTQuantFinancial.GexWeisWave GexWeisWave(ISeries<double> input, int period)
		{
			if (cacheGexWeisWave != null)
				for (int idx = 0; idx < cacheGexWeisWave.Length; idx++)
					if (cacheGexWeisWave[idx].Period == period && cacheGexWeisWave[idx].EqualsInput(input))
						return cacheGexWeisWave[idx];
			return CacheIndicator<GexNTQuantFinancial.GexWeisWave>(new GexNTQuantFinancial.GexWeisWave(){ Period = period }, input, ref cacheGexWeisWave);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial()
		{
			return indicator.GexCumulativeDeltaNTQuantFinancial(Input);
		}

		public Indicators.GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial()
		{
			return indicator.GexDeltaVolumeNTQuantFinancial(Input);
		}

		public Indicators.GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(float opacityBars, bool showSocials)
		{
			return indicator.GexGamaBarsAutomaticNTQuantFinancial(Input, opacityBars, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return indicator.GexGamaBarsNTQauntFinancial(Input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsAutomaticNTQuantFinancial(Input, font, customFontDisplayText, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsNTQuantFinancial(Input, parameters, font, customFontDisplayText, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return indicator.GexMultiPropFirmManager(Input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public Indicators.GexNTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(int cumulationLength, bool highlight)
		{
			return indicator.GexNewCumulativeDelta(Input, cumulationLength, highlight);
		}

		public Indicators.GexNTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(int period, int smooth)
		{
			return indicator.RSINTQuantFinancial(Input, period, smooth);
		}

		public Indicators.GexNTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(bool isUsingRTHSession)
		{
			return indicator.SettlementPriceNTQuantFinancial(Input, isUsingRTHSession);
		}

		public Indicators.GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(int wMSize, int wMOpacity, string customText)
		{
			return indicator.GexTextGraphicSymbolNTQuantFinancial(Input, wMSize, wMOpacity, customText);
		}

		public Indicators.GexNTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(int resolution)
		{
			return indicator.VolumeProfileNtQuantFinancial(Input, resolution);
		}

		public Indicators.GexNTQuantFinancial.GexWeisWave GexWeisWave(int period)
		{
			return indicator.GexWeisWave(Input, period);
		}


		
		public Indicators.GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial(ISeries<double> input )
		{
			return indicator.GexCumulativeDeltaNTQuantFinancial(input);
		}

		public Indicators.GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial(ISeries<double> input )
		{
			return indicator.GexDeltaVolumeNTQuantFinancial(input);
		}

		public Indicators.GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(ISeries<double> input , float opacityBars, bool showSocials)
		{
			return indicator.GexGamaBarsAutomaticNTQuantFinancial(input, opacityBars, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(ISeries<double> input , float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return indicator.GexGamaBarsNTQauntFinancial(input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(ISeries<double> input , SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsAutomaticNTQuantFinancial(input, font, customFontDisplayText, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(ISeries<double> input , string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsNTQuantFinancial(input, parameters, font, customFontDisplayText, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(ISeries<double> input , double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return indicator.GexMultiPropFirmManager(input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public Indicators.GexNTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(ISeries<double> input , int cumulationLength, bool highlight)
		{
			return indicator.GexNewCumulativeDelta(input, cumulationLength, highlight);
		}

		public Indicators.GexNTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(ISeries<double> input , int period, int smooth)
		{
			return indicator.RSINTQuantFinancial(input, period, smooth);
		}

		public Indicators.GexNTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(ISeries<double> input , bool isUsingRTHSession)
		{
			return indicator.SettlementPriceNTQuantFinancial(input, isUsingRTHSession);
		}

		public Indicators.GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(ISeries<double> input , int wMSize, int wMOpacity, string customText)
		{
			return indicator.GexTextGraphicSymbolNTQuantFinancial(input, wMSize, wMOpacity, customText);
		}

		public Indicators.GexNTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(ISeries<double> input , int resolution)
		{
			return indicator.VolumeProfileNtQuantFinancial(input, resolution);
		}

		public Indicators.GexNTQuantFinancial.GexWeisWave GexWeisWave(ISeries<double> input , int period)
		{
			return indicator.GexWeisWave(input, period);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial()
		{
			return indicator.GexCumulativeDeltaNTQuantFinancial(Input);
		}

		public Indicators.GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial()
		{
			return indicator.GexDeltaVolumeNTQuantFinancial(Input);
		}

		public Indicators.GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(float opacityBars, bool showSocials)
		{
			return indicator.GexGamaBarsAutomaticNTQuantFinancial(Input, opacityBars, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return indicator.GexGamaBarsNTQauntFinancial(Input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsAutomaticNTQuantFinancial(Input, font, customFontDisplayText, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsNTQuantFinancial(Input, parameters, font, customFontDisplayText, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return indicator.GexMultiPropFirmManager(Input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public Indicators.GexNTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(int cumulationLength, bool highlight)
		{
			return indicator.GexNewCumulativeDelta(Input, cumulationLength, highlight);
		}

		public Indicators.GexNTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(int period, int smooth)
		{
			return indicator.RSINTQuantFinancial(Input, period, smooth);
		}

		public Indicators.GexNTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(bool isUsingRTHSession)
		{
			return indicator.SettlementPriceNTQuantFinancial(Input, isUsingRTHSession);
		}

		public Indicators.GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(int wMSize, int wMOpacity, string customText)
		{
			return indicator.GexTextGraphicSymbolNTQuantFinancial(Input, wMSize, wMOpacity, customText);
		}

		public Indicators.GexNTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(int resolution)
		{
			return indicator.VolumeProfileNtQuantFinancial(Input, resolution);
		}

		public Indicators.GexNTQuantFinancial.GexWeisWave GexWeisWave(int period)
		{
			return indicator.GexWeisWave(Input, period);
		}


		
		public Indicators.GexNTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial(ISeries<double> input )
		{
			return indicator.GexCumulativeDeltaNTQuantFinancial(input);
		}

		public Indicators.GexNTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial(ISeries<double> input )
		{
			return indicator.GexDeltaVolumeNTQuantFinancial(input);
		}

		public Indicators.GexNTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(ISeries<double> input , float opacityBars, bool showSocials)
		{
			return indicator.GexGamaBarsAutomaticNTQuantFinancial(input, opacityBars, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(ISeries<double> input , float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return indicator.GexGamaBarsNTQauntFinancial(input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(ISeries<double> input , SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsAutomaticNTQuantFinancial(input, font, customFontDisplayText, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(ISeries<double> input , string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsNTQuantFinancial(input, parameters, font, customFontDisplayText, showSocials);
		}

		public Indicators.GexNTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(ISeries<double> input , double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return indicator.GexMultiPropFirmManager(input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public Indicators.GexNTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(ISeries<double> input , int cumulationLength, bool highlight)
		{
			return indicator.GexNewCumulativeDelta(input, cumulationLength, highlight);
		}

		public Indicators.GexNTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(ISeries<double> input , int period, int smooth)
		{
			return indicator.RSINTQuantFinancial(input, period, smooth);
		}

		public Indicators.GexNTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(ISeries<double> input , bool isUsingRTHSession)
		{
			return indicator.SettlementPriceNTQuantFinancial(input, isUsingRTHSession);
		}

		public Indicators.GexNTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(ISeries<double> input , int wMSize, int wMOpacity, string customText)
		{
			return indicator.GexTextGraphicSymbolNTQuantFinancial(input, wMSize, wMOpacity, customText);
		}

		public Indicators.GexNTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(ISeries<double> input , int resolution)
		{
			return indicator.VolumeProfileNtQuantFinancial(input, resolution);
		}

		public Indicators.GexNTQuantFinancial.GexWeisWave GexWeisWave(ISeries<double> input , int period)
		{
			return indicator.GexWeisWave(input, period);
		}

	}
}

#endregion
