#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial[] cacheGexCumulativeDeltaNTQuantFinancial;
		private NTQuantFinancial.GexDeltaVolumeNTQuantFinancial[] cacheGexDeltaVolumeNTQuantFinancial;
		private NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial[] cacheGexGamaBarsAutomaticNTQuantFinancial;
		private NTQuantFinancial.GexGamaBarsNTQauntFinancial[] cacheGexGamaBarsNTQauntFinancial;
		private NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial[] cacheGexGamaLevelsAutomaticNTQuantFinancial;
		private NTQuantFinancial.GexGamaLevelsNTQuantFinancial[] cacheGexGamaLevelsNTQuantFinancial;
		private NTQuantFinancial.GexMultiPropFirmManager[] cacheGexMultiPropFirmManager;
		private NTQuantFinancial.GexNewCumulativeDelta[] cacheGexNewCumulativeDelta;
		private NTQuantFinancial.RSINTQuantFinancial[] cacheRSINTQuantFinancial;
		private NTQuantFinancial.SettlementPriceNTQuantFinancial[] cacheSettlementPriceNTQuantFinancial;
		private NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial[] cacheGexTextGraphicSymbolNTQuantFinancial;
		private NTQuantFinancial.GEXVolatilityPercenty[] cacheGEXVolatilityPercenty;
		private NTQuantFinancial.VolumeProfileNtQuantFinancial[] cacheVolumeProfileNtQuantFinancial;
		private NTQuantFinancial.GexVWAPPBands[] cacheGexVWAPPBands;
		private NTQuantFinancial.GexWeisWave[] cacheGexWeisWave;

		
		public NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial()
		{
			return GexCumulativeDeltaNTQuantFinancial(Input);
		}

		public NTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial()
		{
			return GexDeltaVolumeNTQuantFinancial(Input);
		}

		public NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(float opacityBars, bool showSocials)
		{
			return GexGamaBarsAutomaticNTQuantFinancial(Input, opacityBars, showSocials);
		}

		public NTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return GexGamaBarsNTQauntFinancial(Input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return GexGamaLevelsAutomaticNTQuantFinancial(Input, font, customFontDisplayText, showSocials);
		}

		public NTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return GexGamaLevelsNTQuantFinancial(Input, parameters, font, customFontDisplayText, showSocials);
		}

		public NTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return GexMultiPropFirmManager(Input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public NTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(int cumulationLength, bool highlight)
		{
			return GexNewCumulativeDelta(Input, cumulationLength, highlight);
		}

		public NTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(int period, int smooth)
		{
			return RSINTQuantFinancial(Input, period, smooth);
		}

		public NTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(bool isUsingRTHSession)
		{
			return SettlementPriceNTQuantFinancial(Input, isUsingRTHSession);
		}

		public NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(int wMSize, int wMOpacity, string customText)
		{
			return GexTextGraphicSymbolNTQuantFinancial(Input, wMSize, wMOpacity, customText);
		}

		public NTQuantFinancial.GEXVolatilityPercenty GEXVolatilityPercenty(bool isTextLines, bool isLinesPreviousDay, bool isLinesCurrentDay, bool isLinesPercentageVariation, SimpleFont font)
		{
			return GEXVolatilityPercenty(Input, isTextLines, isLinesPreviousDay, isLinesCurrentDay, isLinesPercentageVariation, font);
		}

		public NTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(bool extendPocLines, int resolution)
		{
			return VolumeProfileNtQuantFinancial(Input, extendPocLines, resolution);
		}

		public NTQuantFinancial.GexVWAPPBands GexVWAPPBands(GexSessionTypeVWAPD sessionType, GexBandTypeVWAPD bandType, GexTimeZonesVWAPD customTZSelector, string s_CustomSessionStart, string s_CustomSessionEnd, double multiplierSD1, double multiplierSD2, double multiplierSD3, double multiplierQR1, double multiplierQR2, double multiplierQR3)
		{
			return GexVWAPPBands(Input, sessionType, bandType, customTZSelector, s_CustomSessionStart, s_CustomSessionEnd, multiplierSD1, multiplierSD2, multiplierSD3, multiplierQR1, multiplierQR2, multiplierQR3);
		}

		public NTQuantFinancial.GexWeisWave GexWeisWave(int period)
		{
			return GexWeisWave(Input, period);
		}


		
		public NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial(ISeries<double> input)
		{
			if (cacheGexCumulativeDeltaNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexCumulativeDeltaNTQuantFinancial.Length; idx++)
					if ( cacheGexCumulativeDeltaNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexCumulativeDeltaNTQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial>(new NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial(), input, ref cacheGexCumulativeDeltaNTQuantFinancial);
		}

		public NTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial(ISeries<double> input)
		{
			if (cacheGexDeltaVolumeNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexDeltaVolumeNTQuantFinancial.Length; idx++)
					if ( cacheGexDeltaVolumeNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexDeltaVolumeNTQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.GexDeltaVolumeNTQuantFinancial>(new NTQuantFinancial.GexDeltaVolumeNTQuantFinancial(), input, ref cacheGexDeltaVolumeNTQuantFinancial);
		}

		public NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(ISeries<double> input, float opacityBars, bool showSocials)
		{
			if (cacheGexGamaBarsAutomaticNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexGamaBarsAutomaticNTQuantFinancial.Length; idx++)
					if (cacheGexGamaBarsAutomaticNTQuantFinancial[idx].opacityBars == opacityBars && cacheGexGamaBarsAutomaticNTQuantFinancial[idx].showSocials == showSocials && cacheGexGamaBarsAutomaticNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexGamaBarsAutomaticNTQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial>(new NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial(){ opacityBars = opacityBars, showSocials = showSocials }, input, ref cacheGexGamaBarsAutomaticNTQuantFinancial);
		}

		public NTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(ISeries<double> input, float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			if (cacheGexGamaBarsNTQauntFinancial != null)
				for (int idx = 0; idx < cacheGexGamaBarsNTQauntFinancial.Length; idx++)
					if (cacheGexGamaBarsNTQauntFinancial[idx].opacityBars == opacityBars && cacheGexGamaBarsNTQauntFinancial[idx].scaleGex == scaleGex && cacheGexGamaBarsNTQauntFinancial[idx].minimumGex == minimumGex && cacheGexGamaBarsNTQauntFinancial[idx].GexJson == gexJson && cacheGexGamaBarsNTQauntFinancial[idx].showSocials == showSocials && cacheGexGamaBarsNTQauntFinancial[idx].EqualsInput(input))
						return cacheGexGamaBarsNTQauntFinancial[idx];
			return CacheIndicator<NTQuantFinancial.GexGamaBarsNTQauntFinancial>(new NTQuantFinancial.GexGamaBarsNTQauntFinancial(){ opacityBars = opacityBars, scaleGex = scaleGex, minimumGex = minimumGex, GexJson = gexJson, showSocials = showSocials }, input, ref cacheGexGamaBarsNTQauntFinancial);
		}

		public NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(ISeries<double> input, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			if (cacheGexGamaLevelsAutomaticNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexGamaLevelsAutomaticNTQuantFinancial.Length; idx++)
					if (cacheGexGamaLevelsAutomaticNTQuantFinancial[idx].Font == font && cacheGexGamaLevelsAutomaticNTQuantFinancial[idx].customFontDisplayText == customFontDisplayText && cacheGexGamaLevelsAutomaticNTQuantFinancial[idx].showSocials == showSocials && cacheGexGamaLevelsAutomaticNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexGamaLevelsAutomaticNTQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial>(new NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial(){ Font = font, customFontDisplayText = customFontDisplayText, showSocials = showSocials }, input, ref cacheGexGamaLevelsAutomaticNTQuantFinancial);
		}

		public NTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(ISeries<double> input, string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			if (cacheGexGamaLevelsNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexGamaLevelsNTQuantFinancial.Length; idx++)
					if (cacheGexGamaLevelsNTQuantFinancial[idx].Parameters == parameters && cacheGexGamaLevelsNTQuantFinancial[idx].Font == font && cacheGexGamaLevelsNTQuantFinancial[idx].customFontDisplayText == customFontDisplayText && cacheGexGamaLevelsNTQuantFinancial[idx].showSocials == showSocials && cacheGexGamaLevelsNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexGamaLevelsNTQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.GexGamaLevelsNTQuantFinancial>(new NTQuantFinancial.GexGamaLevelsNTQuantFinancial(){ Parameters = parameters, Font = font, customFontDisplayText = customFontDisplayText, showSocials = showSocials }, input, ref cacheGexGamaLevelsNTQuantFinancial);
		}

		public NTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(ISeries<double> input, double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			if (cacheGexMultiPropFirmManager != null)
				for (int idx = 0; idx < cacheGexMultiPropFirmManager.Length; idx++)
					if (cacheGexMultiPropFirmManager[idx].GainLimit == gainLimit && cacheGexMultiPropFirmManager[idx].StopLimit == stopLimit && cacheGexMultiPropFirmManager[idx].Font == font && cacheGexMultiPropFirmManager[idx].StopFillBrush == stopFillBrush && cacheGexMultiPropFirmManager[idx].TargetFillBrush == targetFillBrush && cacheGexMultiPropFirmManager[idx].OutlineBrush == outlineBrush && cacheGexMultiPropFirmManager[idx].TextBrush == textBrush && cacheGexMultiPropFirmManager[idx].MasterAccount_name == masterAccount_name && cacheGexMultiPropFirmManager[idx].Accountname_1 == accountname_1 && cacheGexMultiPropFirmManager[idx].Accountname_2 == accountname_2 && cacheGexMultiPropFirmManager[idx].Accountname_3 == accountname_3 && cacheGexMultiPropFirmManager[idx].Accountname_4 == accountname_4 && cacheGexMultiPropFirmManager[idx].Accountname_5 == accountname_5 && cacheGexMultiPropFirmManager[idx].EqualsInput(input))
						return cacheGexMultiPropFirmManager[idx];
			return CacheIndicator<NTQuantFinancial.GexMultiPropFirmManager>(new NTQuantFinancial.GexMultiPropFirmManager(){ GainLimit = gainLimit, StopLimit = stopLimit, Font = font, StopFillBrush = stopFillBrush, TargetFillBrush = targetFillBrush, OutlineBrush = outlineBrush, TextBrush = textBrush, MasterAccount_name = masterAccount_name, Accountname_1 = accountname_1, Accountname_2 = accountname_2, Accountname_3 = accountname_3, Accountname_4 = accountname_4, Accountname_5 = accountname_5 }, input, ref cacheGexMultiPropFirmManager);
		}

		public NTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(ISeries<double> input, int cumulationLength, bool highlight)
		{
			if (cacheGexNewCumulativeDelta != null)
				for (int idx = 0; idx < cacheGexNewCumulativeDelta.Length; idx++)
					if (cacheGexNewCumulativeDelta[idx].CumulationLength == cumulationLength && cacheGexNewCumulativeDelta[idx].Highlight == highlight && cacheGexNewCumulativeDelta[idx].EqualsInput(input))
						return cacheGexNewCumulativeDelta[idx];
			return CacheIndicator<NTQuantFinancial.GexNewCumulativeDelta>(new NTQuantFinancial.GexNewCumulativeDelta(){ CumulationLength = cumulationLength, Highlight = highlight }, input, ref cacheGexNewCumulativeDelta);
		}

		public NTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(ISeries<double> input, int period, int smooth)
		{
			if (cacheRSINTQuantFinancial != null)
				for (int idx = 0; idx < cacheRSINTQuantFinancial.Length; idx++)
					if (cacheRSINTQuantFinancial[idx].Period == period && cacheRSINTQuantFinancial[idx].Smooth == smooth && cacheRSINTQuantFinancial[idx].EqualsInput(input))
						return cacheRSINTQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.RSINTQuantFinancial>(new NTQuantFinancial.RSINTQuantFinancial(){ Period = period, Smooth = smooth }, input, ref cacheRSINTQuantFinancial);
		}

		public NTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(ISeries<double> input, bool isUsingRTHSession)
		{
			if (cacheSettlementPriceNTQuantFinancial != null)
				for (int idx = 0; idx < cacheSettlementPriceNTQuantFinancial.Length; idx++)
					if (cacheSettlementPriceNTQuantFinancial[idx].IsUsingRTHSession == isUsingRTHSession && cacheSettlementPriceNTQuantFinancial[idx].EqualsInput(input))
						return cacheSettlementPriceNTQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.SettlementPriceNTQuantFinancial>(new NTQuantFinancial.SettlementPriceNTQuantFinancial(){ IsUsingRTHSession = isUsingRTHSession }, input, ref cacheSettlementPriceNTQuantFinancial);
		}

		public NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(ISeries<double> input, int wMSize, int wMOpacity, string customText)
		{
			if (cacheGexTextGraphicSymbolNTQuantFinancial != null)
				for (int idx = 0; idx < cacheGexTextGraphicSymbolNTQuantFinancial.Length; idx++)
					if (cacheGexTextGraphicSymbolNTQuantFinancial[idx].WMSize == wMSize && cacheGexTextGraphicSymbolNTQuantFinancial[idx].WMOpacity == wMOpacity && cacheGexTextGraphicSymbolNTQuantFinancial[idx].CustomText == customText && cacheGexTextGraphicSymbolNTQuantFinancial[idx].EqualsInput(input))
						return cacheGexTextGraphicSymbolNTQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial>(new NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial(){ WMSize = wMSize, WMOpacity = wMOpacity, CustomText = customText }, input, ref cacheGexTextGraphicSymbolNTQuantFinancial);
		}

		public NTQuantFinancial.GEXVolatilityPercenty GEXVolatilityPercenty(ISeries<double> input, bool isTextLines, bool isLinesPreviousDay, bool isLinesCurrentDay, bool isLinesPercentageVariation, SimpleFont font)
		{
			if (cacheGEXVolatilityPercenty != null)
				for (int idx = 0; idx < cacheGEXVolatilityPercenty.Length; idx++)
					if (cacheGEXVolatilityPercenty[idx].IsTextLines == isTextLines && cacheGEXVolatilityPercenty[idx].IsLinesPreviousDay == isLinesPreviousDay && cacheGEXVolatilityPercenty[idx].IsLinesCurrentDay == isLinesCurrentDay && cacheGEXVolatilityPercenty[idx].IsLinesPercentageVariation == isLinesPercentageVariation && cacheGEXVolatilityPercenty[idx].Font == font && cacheGEXVolatilityPercenty[idx].EqualsInput(input))
						return cacheGEXVolatilityPercenty[idx];
			return CacheIndicator<NTQuantFinancial.GEXVolatilityPercenty>(new NTQuantFinancial.GEXVolatilityPercenty(){ IsTextLines = isTextLines, IsLinesPreviousDay = isLinesPreviousDay, IsLinesCurrentDay = isLinesCurrentDay, IsLinesPercentageVariation = isLinesPercentageVariation, Font = font }, input, ref cacheGEXVolatilityPercenty);
		}

		public NTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(ISeries<double> input, bool extendPocLines, int resolution)
		{
			if (cacheVolumeProfileNtQuantFinancial != null)
				for (int idx = 0; idx < cacheVolumeProfileNtQuantFinancial.Length; idx++)
					if (cacheVolumeProfileNtQuantFinancial[idx].ExtendPocLines == extendPocLines && cacheVolumeProfileNtQuantFinancial[idx].Resolution == resolution && cacheVolumeProfileNtQuantFinancial[idx].EqualsInput(input))
						return cacheVolumeProfileNtQuantFinancial[idx];
			return CacheIndicator<NTQuantFinancial.VolumeProfileNtQuantFinancial>(new NTQuantFinancial.VolumeProfileNtQuantFinancial(){ ExtendPocLines = extendPocLines, Resolution = resolution }, input, ref cacheVolumeProfileNtQuantFinancial);
		}

		public NTQuantFinancial.GexVWAPPBands GexVWAPPBands(ISeries<double> input, GexSessionTypeVWAPD sessionType, GexBandTypeVWAPD bandType, GexTimeZonesVWAPD customTZSelector, string s_CustomSessionStart, string s_CustomSessionEnd, double multiplierSD1, double multiplierSD2, double multiplierSD3, double multiplierQR1, double multiplierQR2, double multiplierQR3)
		{
			if (cacheGexVWAPPBands != null)
				for (int idx = 0; idx < cacheGexVWAPPBands.Length; idx++)
					if (cacheGexVWAPPBands[idx].SessionType == sessionType && cacheGexVWAPPBands[idx].BandType == bandType && cacheGexVWAPPBands[idx].CustomTZSelector == customTZSelector && cacheGexVWAPPBands[idx].S_CustomSessionStart == s_CustomSessionStart && cacheGexVWAPPBands[idx].S_CustomSessionEnd == s_CustomSessionEnd && cacheGexVWAPPBands[idx].MultiplierSD1 == multiplierSD1 && cacheGexVWAPPBands[idx].MultiplierSD2 == multiplierSD2 && cacheGexVWAPPBands[idx].MultiplierSD3 == multiplierSD3 && cacheGexVWAPPBands[idx].MultiplierQR1 == multiplierQR1 && cacheGexVWAPPBands[idx].MultiplierQR2 == multiplierQR2 && cacheGexVWAPPBands[idx].MultiplierQR3 == multiplierQR3 && cacheGexVWAPPBands[idx].EqualsInput(input))
						return cacheGexVWAPPBands[idx];
			return CacheIndicator<NTQuantFinancial.GexVWAPPBands>(new NTQuantFinancial.GexVWAPPBands(){ SessionType = sessionType, BandType = bandType, CustomTZSelector = customTZSelector, S_CustomSessionStart = s_CustomSessionStart, S_CustomSessionEnd = s_CustomSessionEnd, MultiplierSD1 = multiplierSD1, MultiplierSD2 = multiplierSD2, MultiplierSD3 = multiplierSD3, MultiplierQR1 = multiplierQR1, MultiplierQR2 = multiplierQR2, MultiplierQR3 = multiplierQR3 }, input, ref cacheGexVWAPPBands);
		}

		public NTQuantFinancial.GexWeisWave GexWeisWave(ISeries<double> input, int period)
		{
			if (cacheGexWeisWave != null)
				for (int idx = 0; idx < cacheGexWeisWave.Length; idx++)
					if (cacheGexWeisWave[idx].Period == period && cacheGexWeisWave[idx].EqualsInput(input))
						return cacheGexWeisWave[idx];
			return CacheIndicator<NTQuantFinancial.GexWeisWave>(new NTQuantFinancial.GexWeisWave(){ Period = period }, input, ref cacheGexWeisWave);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial()
		{
			return indicator.GexCumulativeDeltaNTQuantFinancial(Input);
		}

		public Indicators.NTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial()
		{
			return indicator.GexDeltaVolumeNTQuantFinancial(Input);
		}

		public Indicators.NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(float opacityBars, bool showSocials)
		{
			return indicator.GexGamaBarsAutomaticNTQuantFinancial(Input, opacityBars, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return indicator.GexGamaBarsNTQauntFinancial(Input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsAutomaticNTQuantFinancial(Input, font, customFontDisplayText, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsNTQuantFinancial(Input, parameters, font, customFontDisplayText, showSocials);
		}

		public Indicators.NTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return indicator.GexMultiPropFirmManager(Input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public Indicators.NTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(int cumulationLength, bool highlight)
		{
			return indicator.GexNewCumulativeDelta(Input, cumulationLength, highlight);
		}

		public Indicators.NTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(int period, int smooth)
		{
			return indicator.RSINTQuantFinancial(Input, period, smooth);
		}

		public Indicators.NTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(bool isUsingRTHSession)
		{
			return indicator.SettlementPriceNTQuantFinancial(Input, isUsingRTHSession);
		}

		public Indicators.NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(int wMSize, int wMOpacity, string customText)
		{
			return indicator.GexTextGraphicSymbolNTQuantFinancial(Input, wMSize, wMOpacity, customText);
		}

		public Indicators.NTQuantFinancial.GEXVolatilityPercenty GEXVolatilityPercenty(bool isTextLines, bool isLinesPreviousDay, bool isLinesCurrentDay, bool isLinesPercentageVariation, SimpleFont font)
		{
			return indicator.GEXVolatilityPercenty(Input, isTextLines, isLinesPreviousDay, isLinesCurrentDay, isLinesPercentageVariation, font);
		}

		public Indicators.NTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(bool extendPocLines, int resolution)
		{
			return indicator.VolumeProfileNtQuantFinancial(Input, extendPocLines, resolution);
		}

		public Indicators.NTQuantFinancial.GexVWAPPBands GexVWAPPBands(GexSessionTypeVWAPD sessionType, GexBandTypeVWAPD bandType, GexTimeZonesVWAPD customTZSelector, string s_CustomSessionStart, string s_CustomSessionEnd, double multiplierSD1, double multiplierSD2, double multiplierSD3, double multiplierQR1, double multiplierQR2, double multiplierQR3)
		{
			return indicator.GexVWAPPBands(Input, sessionType, bandType, customTZSelector, s_CustomSessionStart, s_CustomSessionEnd, multiplierSD1, multiplierSD2, multiplierSD3, multiplierQR1, multiplierQR2, multiplierQR3);
		}

		public Indicators.NTQuantFinancial.GexWeisWave GexWeisWave(int period)
		{
			return indicator.GexWeisWave(Input, period);
		}


		
		public Indicators.NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial(ISeries<double> input )
		{
			return indicator.GexCumulativeDeltaNTQuantFinancial(input);
		}

		public Indicators.NTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial(ISeries<double> input )
		{
			return indicator.GexDeltaVolumeNTQuantFinancial(input);
		}

		public Indicators.NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(ISeries<double> input , float opacityBars, bool showSocials)
		{
			return indicator.GexGamaBarsAutomaticNTQuantFinancial(input, opacityBars, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(ISeries<double> input , float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return indicator.GexGamaBarsNTQauntFinancial(input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(ISeries<double> input , SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsAutomaticNTQuantFinancial(input, font, customFontDisplayText, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(ISeries<double> input , string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsNTQuantFinancial(input, parameters, font, customFontDisplayText, showSocials);
		}

		public Indicators.NTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(ISeries<double> input , double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return indicator.GexMultiPropFirmManager(input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public Indicators.NTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(ISeries<double> input , int cumulationLength, bool highlight)
		{
			return indicator.GexNewCumulativeDelta(input, cumulationLength, highlight);
		}

		public Indicators.NTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(ISeries<double> input , int period, int smooth)
		{
			return indicator.RSINTQuantFinancial(input, period, smooth);
		}

		public Indicators.NTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(ISeries<double> input , bool isUsingRTHSession)
		{
			return indicator.SettlementPriceNTQuantFinancial(input, isUsingRTHSession);
		}

		public Indicators.NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(ISeries<double> input , int wMSize, int wMOpacity, string customText)
		{
			return indicator.GexTextGraphicSymbolNTQuantFinancial(input, wMSize, wMOpacity, customText);
		}

		public Indicators.NTQuantFinancial.GEXVolatilityPercenty GEXVolatilityPercenty(ISeries<double> input , bool isTextLines, bool isLinesPreviousDay, bool isLinesCurrentDay, bool isLinesPercentageVariation, SimpleFont font)
		{
			return indicator.GEXVolatilityPercenty(input, isTextLines, isLinesPreviousDay, isLinesCurrentDay, isLinesPercentageVariation, font);
		}

		public Indicators.NTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(ISeries<double> input , bool extendPocLines, int resolution)
		{
			return indicator.VolumeProfileNtQuantFinancial(input, extendPocLines, resolution);
		}

		public Indicators.NTQuantFinancial.GexVWAPPBands GexVWAPPBands(ISeries<double> input , GexSessionTypeVWAPD sessionType, GexBandTypeVWAPD bandType, GexTimeZonesVWAPD customTZSelector, string s_CustomSessionStart, string s_CustomSessionEnd, double multiplierSD1, double multiplierSD2, double multiplierSD3, double multiplierQR1, double multiplierQR2, double multiplierQR3)
		{
			return indicator.GexVWAPPBands(input, sessionType, bandType, customTZSelector, s_CustomSessionStart, s_CustomSessionEnd, multiplierSD1, multiplierSD2, multiplierSD3, multiplierQR1, multiplierQR2, multiplierQR3);
		}

		public Indicators.NTQuantFinancial.GexWeisWave GexWeisWave(ISeries<double> input , int period)
		{
			return indicator.GexWeisWave(input, period);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial()
		{
			return indicator.GexCumulativeDeltaNTQuantFinancial(Input);
		}

		public Indicators.NTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial()
		{
			return indicator.GexDeltaVolumeNTQuantFinancial(Input);
		}

		public Indicators.NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(float opacityBars, bool showSocials)
		{
			return indicator.GexGamaBarsAutomaticNTQuantFinancial(Input, opacityBars, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return indicator.GexGamaBarsNTQauntFinancial(Input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsAutomaticNTQuantFinancial(Input, font, customFontDisplayText, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsNTQuantFinancial(Input, parameters, font, customFontDisplayText, showSocials);
		}

		public Indicators.NTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return indicator.GexMultiPropFirmManager(Input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public Indicators.NTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(int cumulationLength, bool highlight)
		{
			return indicator.GexNewCumulativeDelta(Input, cumulationLength, highlight);
		}

		public Indicators.NTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(int period, int smooth)
		{
			return indicator.RSINTQuantFinancial(Input, period, smooth);
		}

		public Indicators.NTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(bool isUsingRTHSession)
		{
			return indicator.SettlementPriceNTQuantFinancial(Input, isUsingRTHSession);
		}

		public Indicators.NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(int wMSize, int wMOpacity, string customText)
		{
			return indicator.GexTextGraphicSymbolNTQuantFinancial(Input, wMSize, wMOpacity, customText);
		}

		public Indicators.NTQuantFinancial.GEXVolatilityPercenty GEXVolatilityPercenty(bool isTextLines, bool isLinesPreviousDay, bool isLinesCurrentDay, bool isLinesPercentageVariation, SimpleFont font)
		{
			return indicator.GEXVolatilityPercenty(Input, isTextLines, isLinesPreviousDay, isLinesCurrentDay, isLinesPercentageVariation, font);
		}

		public Indicators.NTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(bool extendPocLines, int resolution)
		{
			return indicator.VolumeProfileNtQuantFinancial(Input, extendPocLines, resolution);
		}

		public Indicators.NTQuantFinancial.GexVWAPPBands GexVWAPPBands(GexSessionTypeVWAPD sessionType, GexBandTypeVWAPD bandType, GexTimeZonesVWAPD customTZSelector, string s_CustomSessionStart, string s_CustomSessionEnd, double multiplierSD1, double multiplierSD2, double multiplierSD3, double multiplierQR1, double multiplierQR2, double multiplierQR3)
		{
			return indicator.GexVWAPPBands(Input, sessionType, bandType, customTZSelector, s_CustomSessionStart, s_CustomSessionEnd, multiplierSD1, multiplierSD2, multiplierSD3, multiplierQR1, multiplierQR2, multiplierQR3);
		}

		public Indicators.NTQuantFinancial.GexWeisWave GexWeisWave(int period)
		{
			return indicator.GexWeisWave(Input, period);
		}


		
		public Indicators.NTQuantFinancial.GexCumulativeDeltaNTQuantFinancial GexCumulativeDeltaNTQuantFinancial(ISeries<double> input )
		{
			return indicator.GexCumulativeDeltaNTQuantFinancial(input);
		}

		public Indicators.NTQuantFinancial.GexDeltaVolumeNTQuantFinancial GexDeltaVolumeNTQuantFinancial(ISeries<double> input )
		{
			return indicator.GexDeltaVolumeNTQuantFinancial(input);
		}

		public Indicators.NTQuantFinancial.GexGamaBarsAutomaticNTQuantFinancial GexGamaBarsAutomaticNTQuantFinancial(ISeries<double> input , float opacityBars, bool showSocials)
		{
			return indicator.GexGamaBarsAutomaticNTQuantFinancial(input, opacityBars, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaBarsNTQauntFinancial GexGamaBarsNTQauntFinancial(ISeries<double> input , float opacityBars, int scaleGex, int minimumGex, string gexJson, bool showSocials)
		{
			return indicator.GexGamaBarsNTQauntFinancial(input, opacityBars, scaleGex, minimumGex, gexJson, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaLevelsAutomaticNTQuantFinancial GexGamaLevelsAutomaticNTQuantFinancial(ISeries<double> input , SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsAutomaticNTQuantFinancial(input, font, customFontDisplayText, showSocials);
		}

		public Indicators.NTQuantFinancial.GexGamaLevelsNTQuantFinancial GexGamaLevelsNTQuantFinancial(ISeries<double> input , string parameters, SimpleFont font, SimpleFont customFontDisplayText, bool showSocials)
		{
			return indicator.GexGamaLevelsNTQuantFinancial(input, parameters, font, customFontDisplayText, showSocials);
		}

		public Indicators.NTQuantFinancial.GexMultiPropFirmManager GexMultiPropFirmManager(ISeries<double> input , double gainLimit, double stopLimit, SimpleFont font, Brush stopFillBrush, Brush targetFillBrush, Brush outlineBrush, Brush textBrush, string masterAccount_name, string accountname_1, string accountname_2, string accountname_3, string accountname_4, string accountname_5)
		{
			return indicator.GexMultiPropFirmManager(input, gainLimit, stopLimit, font, stopFillBrush, targetFillBrush, outlineBrush, textBrush, masterAccount_name, accountname_1, accountname_2, accountname_3, accountname_4, accountname_5);
		}

		public Indicators.NTQuantFinancial.GexNewCumulativeDelta GexNewCumulativeDelta(ISeries<double> input , int cumulationLength, bool highlight)
		{
			return indicator.GexNewCumulativeDelta(input, cumulationLength, highlight);
		}

		public Indicators.NTQuantFinancial.RSINTQuantFinancial RSINTQuantFinancial(ISeries<double> input , int period, int smooth)
		{
			return indicator.RSINTQuantFinancial(input, period, smooth);
		}

		public Indicators.NTQuantFinancial.SettlementPriceNTQuantFinancial SettlementPriceNTQuantFinancial(ISeries<double> input , bool isUsingRTHSession)
		{
			return indicator.SettlementPriceNTQuantFinancial(input, isUsingRTHSession);
		}

		public Indicators.NTQuantFinancial.GexTextGraphicSymbolNTQuantFinancial GexTextGraphicSymbolNTQuantFinancial(ISeries<double> input , int wMSize, int wMOpacity, string customText)
		{
			return indicator.GexTextGraphicSymbolNTQuantFinancial(input, wMSize, wMOpacity, customText);
		}

		public Indicators.NTQuantFinancial.GEXVolatilityPercenty GEXVolatilityPercenty(ISeries<double> input , bool isTextLines, bool isLinesPreviousDay, bool isLinesCurrentDay, bool isLinesPercentageVariation, SimpleFont font)
		{
			return indicator.GEXVolatilityPercenty(input, isTextLines, isLinesPreviousDay, isLinesCurrentDay, isLinesPercentageVariation, font);
		}

		public Indicators.NTQuantFinancial.VolumeProfileNtQuantFinancial VolumeProfileNtQuantFinancial(ISeries<double> input , bool extendPocLines, int resolution)
		{
			return indicator.VolumeProfileNtQuantFinancial(input, extendPocLines, resolution);
		}

		public Indicators.NTQuantFinancial.GexVWAPPBands GexVWAPPBands(ISeries<double> input , GexSessionTypeVWAPD sessionType, GexBandTypeVWAPD bandType, GexTimeZonesVWAPD customTZSelector, string s_CustomSessionStart, string s_CustomSessionEnd, double multiplierSD1, double multiplierSD2, double multiplierSD3, double multiplierQR1, double multiplierQR2, double multiplierQR3)
		{
			return indicator.GexVWAPPBands(input, sessionType, bandType, customTZSelector, s_CustomSessionStart, s_CustomSessionEnd, multiplierSD1, multiplierSD2, multiplierSD3, multiplierQR1, multiplierQR2, multiplierQR3);
		}

		public Indicators.NTQuantFinancial.GexWeisWave GexWeisWave(ISeries<double> input , int period)
		{
			return indicator.GexWeisWave(input, period);
		}

	}
}

#endregion
